'use client';

import { useEffect, useState } from 'react';
import { useAdminAuth, AdminHeader, AdminNav } from '@/components/AdminAuth';

interface ScorecardInfo {
  id: string; member_id: string; name: string; handicap: number;
  status: string; total_points: number; total_gross: number; holes_completed: number;
}

export default function AdminScoringPage() {
  const { isAuth, checking, logout } = useAdminAuth();
  const [scorecards, setScorecards] = useState<ScorecardInfo[]>([]);
  const [confirmed, setConfirmed] = useState<Array<{ member_id: string; name: string; handicap: number }>>([]);
  const [eventName, setEventName] = useState('');
  const [loading, setLoading] = useState(true);

  const loadData = () => {
    Promise.all([
      fetch('/api/leaderboard').then(r => r.json()),
      fetch('/api/rsvps').then(r => r.json()),
      fetch('/api/events').then(r => r.json()),
    ]).then(([lb, rsvps, event]) => {
      setScorecards(lb.leaderboard || []);
      setConfirmed((rsvps || []).filter((r: { status: string }) => r.status === 'confirmed')
        .map((r: { member_id: string; name: string; handicap: number }) => ({
          member_id: r.member_id, name: r.name, handicap: r.handicap
        })));
      setEventName(event?.name || '');
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => {
    if (!isAuth) return;
    loadData();
    const iv = setInterval(loadData, 15000);
    return () => clearInterval(iv);
  }, [isAuth]);

  if (checking || !isAuth) return null;

  const scoredIds = new Set(scorecards.map(s => s.member_id));
  const notStarted = confirmed.filter(c => !scoredIds.has(c.member_id));
  const submitted = scorecards.filter(s => s.status === 'submitted');
  const inProgress = scorecards.filter(s => s.status !== 'submitted');

  return (
    <div>
      <AdminHeader title="Score Monitoring" onLock={logout} />
      <AdminNav current="/admin/scoring" />

      <div className="max-w-4xl mx-auto px-4 py-6">
        <h2 className="text-lg font-bold text-gray-900 mb-1">{eventName}</h2>
        <p className="text-sm text-gray-500 mb-4">Live scoring overview · Auto-refreshes every 15s</p>

        {/* Summary */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-green-50 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-green-700">{submitted.length}</p>
            <p className="text-xs text-green-600">Submitted</p>
          </div>
          <div className="bg-orange-50 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-orange-700">{inProgress.length}</p>
            <p className="text-xs text-orange-600">On Course</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-gray-700">{notStarted.length}</p>
            <p className="text-xs text-gray-600">Not Started</p>
          </div>
        </div>

        {/* In Progress */}
        {inProgress.length > 0 && (
          <div className="mb-4">
            <h3 className="font-bold text-gray-900 mb-2">⏳ On Course</h3>
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              {inProgress.map((sc, i) => (
                <div key={sc.id} className={`flex items-center px-4 py-3 ${i > 0 ? 'border-t border-gray-50' : ''}`}>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{sc.name}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="w-24 bg-gray-100 rounded-full h-1.5">
                        <div className="bg-orange-500 rounded-full h-1.5" style={{ width: `${(sc.holes_completed / 18) * 100}%` }} />
                      </div>
                      <span className="text-xs text-gray-400">Thru {sc.holes_completed}</span>
                    </div>
                  </div>
                  <p className="text-lg font-bold text-fairway-900">{sc.total_points || 0}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Submitted */}
        {submitted.length > 0 && (
          <div className="mb-4">
            <h3 className="font-bold text-gray-900 mb-2">✅ Submitted</h3>
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              {submitted.map((sc, i) => (
                <div key={sc.id} className={`flex items-center px-4 py-3 ${i > 0 ? 'border-t border-gray-50' : ''}`}>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{sc.name}</p>
                    <p className="text-xs text-gray-400">Hcp {sc.handicap} · {sc.total_gross} gross</p>
                  </div>
                  <p className="text-lg font-bold text-fairway-900">{sc.total_points}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Not Started */}
        {notStarted.length > 0 && (
          <div>
            <h3 className="font-bold text-gray-900 mb-2">🔴 Not Started</h3>
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              {notStarted.map((p, i) => (
                <div key={p.member_id} className={`flex items-center px-4 py-3 ${i > 0 ? 'border-t border-gray-50' : ''}`}>
                  <div className="flex-1">
                    <p className="font-medium text-sm text-gray-500">{p.name}</p>
                    <p className="text-xs text-gray-400">Hcp {p.handicap}</p>
                  </div>
                  <button className="text-xs bg-yellow-100 text-yellow-800 px-3 py-1 rounded-lg font-medium">
                    📲 Prod
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
