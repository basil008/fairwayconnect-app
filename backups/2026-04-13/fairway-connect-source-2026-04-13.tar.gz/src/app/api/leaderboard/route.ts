import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export const dynamic = 'force-dynamic';

export async function GET() {
  await seedDatabase();
  const db = getDb();

  // Get the current active event (in_progress first, then most recent finalised)
  const inProgressResult = await db.execute("SELECT id FROM events WHERE status = 'in_progress' ORDER BY date DESC LIMIT 1");
  let eventId = inProgressResult.rows[0]?.id as string;

  if (!eventId) {
    const finalisedResult = await db.execute("SELECT id FROM events WHERE status = 'finalised' ORDER BY date DESC LIMIT 1");
    eventId = finalisedResult.rows[0]?.id as string;
  }

  if (!eventId) return NextResponse.json({ leaderboard: [], side_comps: [], live: false });

  const entriesResult = await db.execute({
    sql: `
      SELECT s.id as scorecard_id, s.member_id, s.status, s.total_gross, s.total_points,
             m.name, m.handicap, m.member_type,
             (SELECT COUNT(*) FROM hole_scores WHERE scorecard_id = s.id) as holes_played
      FROM scorecards s
      JOIN members m ON m.id = s.member_id
      WHERE s.event_id = ?
      ORDER BY s.total_points DESC, s.total_gross ASC
    `,
    args: [eventId]
  });
  const entries = entriesResult.rows as unknown as Array<{
    scorecard_id: string; member_id: string; status: string;
    total_gross: number; total_points: number;
    name: string; handicap: number; holes_played: number; member_type: string;
  }>;

  // Get event number to determine which deductions apply
  const eventInfoResult = await db.execute({ sql: 'SELECT event_number FROM events WHERE id = ?', args: [eventId] });
  const eventNumber = (eventInfoResult.rows[0] as any)?.event_number as number || 1;

  // Get deductions for all members — cumulative UP TO this outing (not including this outing's results)
  const deductionsResult = await db.execute({
    sql: `SELECT member_name, first_name, year_starting_deduction,
      outing_1, outing_2, outing_3, outing_4, outing_5, outing_6, outing_7, outing_8
      FROM member_deductions WHERE year = ?`,
    args: [new Date().getFullYear()]
  });
  const deductionMap = new Map<string, number>();
  for (const row of deductionsResult.rows) {
    const r = row as Record<string, unknown>;
    const name = ((r.member_name as string) || '').trim();
    const firstName = ((r.first_name as string) || '').trim();
    // Sum deductions UP TO (but not including) this outing
    // For outing 1: just year_starting_deduction
    // For outing 2: year_starting + outing_1
    // For outing 3: year_starting + outing_1 + outing_2
    let total = Number(r.year_starting_deduction) || 0;
    for (let i = 1; i < eventNumber; i++) {
      total += Number(r[`outing_${i}`]) || 0;
    }
    if (name) deductionMap.set(name.toLowerCase(), total);
    if (firstName && name) deductionMap.set(`${firstName} ${name}`.toLowerCase().trim(), total);
  }

  // Apply deductions to points for overall ranking
  const adjustedEntries = entries.map(entry => {
    const nameLower = entry.name.trim().toLowerCase();
    const deduction = deductionMap.get(nameLower) || 0;
    const adjustedPoints = entry.total_points + deduction; // deductions are negative
    return { ...entry, raw_points: entry.total_points, deduction, adjusted_points: adjustedPoints };
  });

  // Sort by adjusted points descending, then gross ascending
  adjustedEntries.sort((a, b) => {
    if (a.adjusted_points !== b.adjusted_points) return b.adjusted_points - a.adjusted_points;
    return a.total_gross - b.total_gross;
  });

  // Add positions
  let position = 0;
  let lastPoints = -1;
  const leaderboard = adjustedEntries.map((entry, idx) => {
    if (entry.adjusted_points !== lastPoints) {
      position = idx + 1;
    }
    lastPoints = entry.adjusted_points;
    return {
      ...entry,
      total_points: entry.adjusted_points,
      position,
      thru: entry.status === 'submitted' ? 'F' : `${entry.holes_played}`,
    };
  });

  // Side comps
  const sideCompsResult = await db.execute({
    sql: `
      SELECT sc.*, m.name as player_name, m.handicap as player_handicap
      FROM side_comps sc JOIN members m ON m.id = sc.member_id
      WHERE sc.event_id = ?
    `,
    args: [eventId]
  });
  const sideComps = sideCompsResult.rows;

  // Get top 3 overall finishers (they can't win Front 9 / Back 9)
  const top3MemberIds = new Set(
    leaderboard
      .filter(e => e.position <= 3 && e.member_type !== 'visitor')
      .map(e => e.member_id)
  );

  // Get Front 9 scores with tiebreaker data (last 6 = holes 4-9, last 3 = holes 7-9)
  const front9Result = await db.execute({
    sql: `
      SELECT 
        s.member_id,
        m.name, 
        m.handicap, 
        SUM(hs.stableford_points) as front9_pts,
        SUM(CASE WHEN hs.hole_number >= 4 AND hs.hole_number <= 9 THEN hs.stableford_points ELSE 0 END) as last6_pts,
        SUM(CASE WHEN hs.hole_number >= 7 AND hs.hole_number <= 9 THEN hs.stableford_points ELSE 0 END) as last3_pts
      FROM scorecards s
      JOIN members m ON m.id = s.member_id
      JOIN hole_scores hs ON hs.scorecard_id = s.id
      WHERE s.event_id = ? AND s.status = 'submitted' AND hs.hole_number <= 9 AND m.member_type != 'visitor'
      GROUP BY s.id, s.member_id, m.name, m.handicap
      ORDER BY front9_pts DESC, last6_pts DESC, last3_pts DESC
    `,
    args: [eventId]
  });
  
  // Find first player not in top 3
  const front9Candidates = front9Result.rows as unknown as Array<{ 
    member_id: string; name: string; handicap: number; 
    front9_pts: number; last6_pts: number; last3_pts: number 
  }>;
  const front9Winner = front9Candidates.find(c => !top3MemberIds.has(c.member_id));

  // Get Back 9 scores with tiebreaker data (last 6 = holes 13-18, last 3 = holes 16-18)
  const back9Result = await db.execute({
    sql: `
      SELECT 
        s.member_id,
        m.name, 
        m.handicap, 
        SUM(hs.stableford_points) as back9_pts,
        SUM(CASE WHEN hs.hole_number >= 13 AND hs.hole_number <= 18 THEN hs.stableford_points ELSE 0 END) as last6_pts,
        SUM(CASE WHEN hs.hole_number >= 16 AND hs.hole_number <= 18 THEN hs.stableford_points ELSE 0 END) as last3_pts
      FROM scorecards s
      JOIN members m ON m.id = s.member_id
      JOIN hole_scores hs ON hs.scorecard_id = s.id
      WHERE s.event_id = ? AND s.status = 'submitted' AND hs.hole_number > 9 AND m.member_type != 'visitor'
      GROUP BY s.id, s.member_id, m.name, m.handicap
      ORDER BY back9_pts DESC, last6_pts DESC, last3_pts DESC
    `,
    args: [eventId]
  });
  
  // Find first player not in top 3
  const back9Candidates = back9Result.rows as unknown as Array<{ 
    member_id: string; name: string; handicap: number; 
    back9_pts: number; last6_pts: number; last3_pts: number 
  }>;
  const back9Winner = back9Candidates.find(c => !top3MemberIds.has(c.member_id));

  const inProgress = entries.some(e => e.status === 'in_progress');

  // Get event name for context
  const eventResult = await db.execute({ sql: 'SELECT name, course_name, date, status FROM events WHERE id = ?', args: [eventId] });
  const event = eventResult.rows[0] as unknown as { name: string; course_name: string; date: string; status: string } | undefined;

  return NextResponse.json({ 
    leaderboard, 
    side_comps: sideComps, 
    live: inProgress, 
    finalised: event?.status === 'finalised', 
    event_name: event ? `${event.name} — ${event.course_name}` : '',
    event_date: event?.date,
    front9_winner: front9Winner ? { name: front9Winner.name, handicap: front9Winner.handicap, points: front9Winner.front9_pts } : null,
    back9_winner: back9Winner ? { name: back9Winner.name, handicap: back9Winner.handicap, points: back9Winner.back9_pts } : null,
    // Debug: top 3 who can't win 9-hole prizes
    top3_excluded: Array.from(top3MemberIds),
  });
}
