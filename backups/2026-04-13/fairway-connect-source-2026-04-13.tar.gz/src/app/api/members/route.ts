import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';
import { v4 as uuid } from 'uuid';

async function getCurrentEventId(db: ReturnType<typeof getDb>): Promise<string | undefined> {
  const inProgressResult = await db.execute("SELECT id FROM events WHERE status = 'in_progress' ORDER BY date ASC LIMIT 1");
  if (inProgressResult.rows[0]?.id) return inProgressResult.rows[0].id as string;

  const upcomingResult = await db.execute("SELECT id FROM events WHERE status = 'upcoming' ORDER BY date ASC LIMIT 1");
  if (upcomingResult.rows[0]?.id) return upcomingResult.rows[0].id as string;

  const finalisedResult = await db.execute("SELECT id FROM events WHERE status = 'finalised' ORDER BY date DESC LIMIT 1");
  if (finalisedResult.rows[0]?.id) return finalisedResult.rows[0].id as string;

  return undefined;
}

export async function GET() {
  await seedDatabase();
  const db = getDb();
  const eventId = await getCurrentEventId(db);
  
  const membersResult = await db.execute({
    sql: `
      SELECT m.*, m.access_token, r.status as rsvp_status
      FROM members m
      LEFT JOIN rsvps r ON r.member_id = m.id AND r.event_id = ?
    `,
    args: [eventId || '']
  });
  
  // Sort by surname (last word of name)
  const members = membersResult.rows.sort((a, b) => {
    const getSurname = (name: string) => {
      const parts = (name || '').trim().split(/\s+/);
      return parts[parts.length - 1].toLowerCase();
    };
    const surnameA = getSurname(a.name as string);
    const surnameB = getSurname(b.name as string);
    return surnameA.localeCompare(surnameB);
  });
  
  return NextResponse.json(members);
}

export async function POST(req: NextRequest) {
  await seedDatabase();
  const db = getDb();
  const body = await req.json();
  const { name, handicap, email, phone, member_type, event_rsvp } = body;

  if (!name) return NextResponse.json({ error: 'Name required' }, { status: 400 });

  const memberId = uuid();
  await db.execute({
    sql: `
      INSERT INTO members (id, society_id, name, handicap, email, phone, member_type)
      VALUES (?, 'soc_oscar_001', ?, ?, ?, ?, ?)
    `,
    args: [memberId, name, handicap || 28, email || '', phone || '', member_type || 'member']
  });

  // Auto-RSVP to current event if requested
  const eventId = await getCurrentEventId(db);
  if (event_rsvp && eventId) {
    await db.execute({
      sql: 'INSERT INTO rsvps (id, event_id, member_id, status) VALUES (?, ?, ?, ?)',
      args: [uuid(), eventId, memberId, 'confirmed']
    });
  }

  // Log activity
  try {
    await db.execute({
      sql: 'INSERT INTO activity_log (id, event_id, member_id, action, detail) VALUES (?, ?, ?, ?, ?)',
      args: [uuid(), eventId || null, memberId,
        member_type === 'visitor' ? 'visitor_added' : 'member_added',
        `${name} added as ${member_type || 'member'}`]
    });
  } catch { /* non-critical */ }

  return NextResponse.json({ id: memberId, name, handicap: handicap || 28, member_type: member_type || 'member' }, { status: 201 });
}
