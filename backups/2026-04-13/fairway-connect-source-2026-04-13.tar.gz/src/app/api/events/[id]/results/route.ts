import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const db = getDb();

  try {
    // Get event details
    const eventResult = await db.execute({
      sql: `SELECT e.*, c.name as course_name 
            FROM events e 
            LEFT JOIN courses c ON e.course_id = c.id 
            WHERE e.id = ?`,
      args: [id]
    });
    
    if (eventResult.rows.length === 0) {
      return NextResponse.json({ error: 'Event not found' }, { status: 404 });
    }

    const event = eventResult.rows[0];

    // Get all scorecards with member names
    const scorecardsResult = await db.execute({
      sql: `SELECT sc.*, m.name, m.handicap
            FROM scorecards sc
            JOIN members m ON sc.member_id = m.id
            WHERE sc.event_id = ?`,
      args: [id]
    });

    // Get event number for per-outing deduction calculation
    const eventNumber = (event.event_number as number) || 1;

    // Get deductions — cumulative UP TO this outing
    const deductionsResult = await db.execute({
      sql: `SELECT member_name, first_name, year_starting_deduction,
        outing_1, outing_2, outing_3, outing_4, outing_5, outing_6, outing_7, outing_8
        FROM member_deductions WHERE year = ?`,
      args: [new Date().getFullYear()]
    });
    const deductionMap = new Map<string, number>();
    for (const row of deductionsResult.rows) {
      const r = row as Record<string, unknown>;
      const name = ((r.member_name as string) || '').trim();
      const firstName = ((r.first_name as string) || '').trim();
      let total = Number(r.year_starting_deduction) || 0;
      for (let i = 1; i < eventNumber; i++) {
        total += Number(r[`outing_${i}`]) || 0;
      }
      if (name) deductionMap.set(name.toLowerCase(), total);
      if (firstName && name) deductionMap.set(`${firstName} ${name}`.toLowerCase().trim(), total);
    }

    // Get prizes
    const prizesResult = await db.execute({
      sql: `SELECT pa.*, m.name as member_name
            FROM prize_allocations pa
            LEFT JOIN members m ON pa.member_id = m.id
            WHERE pa.event_id = ?
            ORDER BY pa.prize_type, pa.position`,
      args: [id]
    });

    // Get side competitions
    const sideCompsResult = await db.execute({
      sql: `SELECT sc.*, m.name as member_name
            FROM side_comps sc
            LEFT JOIN members m ON sc.member_id = m.id
            WHERE sc.event_id = ?
            ORDER BY sc.type, sc.hole_number`,
      args: [id]
    });

    return NextResponse.json({
      event: {
        id: event.id,
        name: event.name,
        course_name: event.course_name,
        date: event.date,
        format: event.format,
        status: event.status,
      },
      scorecards: scorecardsResult.rows.map(row => {
        const nameLower = ((row.name as string) || '').trim().toLowerCase();
        const surname = ((row.name as string) || '').trim().split(' ').slice(-1)[0].toLowerCase();
        const deduction = deductionMap.get(nameLower) || 0;
        const rawPts = (row.total_points as number) || 0;
        const adjustedPts = rawPts + deduction; // For event prizes only
        return {
          member_id: row.member_id,
          name: row.name,
          handicap: row.handicap,
          total_points: adjustedPts, // Event ranking uses adjusted
          raw_points: rawPts, // GOTY uses raw
          deduction,
          total_gross: row.total_gross || 0,
          holes_completed: row.holes_completed || 0,
          status: row.status,
        };
      }).sort((a, b) => (b.total_points as number) - (a.total_points as number)),
      prizes: prizesResult.rows.map(row => ({
        prize_type: row.prize_type,
        position: row.position,
        label: row.label,
        value: row.value || 0,
        member_name: row.member_name,
      })),
      sideComps: sideCompsResult.rows.map(row => ({
        type: row.type,
        hole_number: row.hole_number,
        member_name: row.member_name,
        value: row.value,
        unit: row.unit,
      })),
    });
  } catch (error) {
    console.error('Error fetching event results:', error);
    return NextResponse.json({ error: 'Failed to fetch results' }, { status: 500 });
  }
}
