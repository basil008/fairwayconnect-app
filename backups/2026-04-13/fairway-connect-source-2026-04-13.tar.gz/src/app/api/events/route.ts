import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export async function GET(request: Request) {
  await seedDatabase();
  const db = getDb();

  const { searchParams } = new URL(request.url);
  const eventId = searchParams.get('id');

  let event: Record<string, unknown> | undefined;

  if (eventId) {
    const eventResult = await db.execute({ sql: 'SELECT * FROM events WHERE id = ?', args: [eventId] });
    event = eventResult.rows[0] as Record<string, unknown> | undefined;
  } else {
    // Default: get the next upcoming event, or the most recently finalised if none upcoming
    const upcomingResult = await db.execute(`
      SELECT * FROM events WHERE status = 'upcoming' OR status = 'in_progress' ORDER BY date ASC LIMIT 1
    `);
    event = upcomingResult.rows[0] as Record<string, unknown> | undefined;

    if (!event) {
      const latestResult = await db.execute('SELECT * FROM events ORDER BY date DESC LIMIT 1');
      event = latestResult.rows[0] as Record<string, unknown> | undefined;
    }
  }

  if (!event) return NextResponse.json(null);

  const holesResult = await db.execute({ sql: 'SELECT * FROM course_holes WHERE event_id = ? ORDER BY hole_number', args: [event.id as string] });
  const holes = holesResult.rows;

  const rsvpCountsResult = await db.execute({
    sql: `SELECT status, COUNT(*) as count FROM rsvps WHERE event_id = ? GROUP BY status`,
    args: [event.id as string]
  });
  const rsvpCounts = rsvpCountsResult.rows;
  const confirmedCount = (rsvpCounts as unknown as Array<{status:string;count:number}>).find(r => r.status === 'confirmed')?.count || 0;

  return NextResponse.json({
    ...event,
    prize_config: event.prize_config ? JSON.parse(event.prize_config as string) : null,
    holes,
    rsvp_counts: rsvpCounts,
    confirmed_count: confirmedCount,
  });
}

export async function POST(request: Request) {
  const db = getDb();
  const body = await request.json();
  const { id, name, course_name, date, format, entry_fee, first_tee, status } = body;

  await db.execute({
    sql: `
      UPDATE events SET name = ?, course_name = ?, date = ?, format = ?, entry_fee = ?, first_tee = ?, status = ?
      WHERE id = ?
    `,
    args: [name, course_name, date, format, entry_fee, first_tee, status, id]
  });

  return NextResponse.json({ success: true });
}
