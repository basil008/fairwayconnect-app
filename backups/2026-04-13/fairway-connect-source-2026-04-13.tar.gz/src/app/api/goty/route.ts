import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const db = getDb();
  const url = new URL(request.url);
  const limit = Number(url.searchParams.get('limit')) || 10;

  // Get active season
  const seasonResult = await db.execute("SELECT * FROM seasons WHERE status = 'active' ORDER BY year DESC LIMIT 1");
  const season = seasonResult.rows[0] as Record<string, unknown> | undefined;
  if (!season) {
    return NextResponse.json({ season: null, standings: [], total_events: 0, rules: 'Best 6 of 8 Stableford scores' });
  }

  const seasonId = season.id as string;
  const seasonYear = season.year as number;

  // Get all finalised events in this season
  const eventsResult = await db.execute({
    sql: `SELECT id, name, course_name, date, event_number FROM events WHERE season_id = ? AND status IN ('finalised', 'in_progress') ORDER BY date ASC`,
    args: [seasonId]
  });
  const events = eventsResult.rows as unknown as Array<{ id: string; name: string; course_name: string; date: string; event_number: number }>;

  // Collect each member's Stableford totals per event
  const memberScores: Record<string, {
    name: string;
    handicap: number;
    scores: Array<{
      event_id: string;
      event_name: string;
      event_date: string;
      points: number;
      position: number;
      counting: boolean;
    }>;
  }> = {};

  for (const evt of events) {
    // Get submitted scorecards for this event (excluding visitors)
    const scorecardsResult = await db.execute({
      sql: `
        SELECT s.member_id, s.total_points, m.name, m.handicap
        FROM scorecards s
        JOIN members m ON m.id = s.member_id
        WHERE s.event_id = ? AND s.status = 'submitted' AND m.member_type != 'visitor'
        ORDER BY s.total_points DESC, s.total_gross ASC
      `,
      args: [evt.id]
    });
    const scorecards = scorecardsResult.rows as unknown as Array<{
      member_id: string;
      total_points: number;
      name: string;
      handicap: number;
    }>;

    for (let i = 0; i < scorecards.length; i++) {
      const sc = scorecards[i];
      const position = i + 1;

      if (!memberScores[sc.member_id]) {
        memberScores[sc.member_id] = {
          name: sc.name,
          handicap: sc.handicap,
          scores: [],
        };
      }

      memberScores[sc.member_id].scores.push({
        event_id: evt.id,
        event_name: evt.course_name || evt.name,
        event_date: evt.date,
        points: sc.total_points,
        position,
        counting: false, // Will mark top 6 below
      });
    }
  }

  // Calculate best 6 of 8 for each member
  const standings = Object.entries(memberScores).map(([memberId, data]) => {
    // Sort scores by points descending
    const sortedByPoints = [...data.scores].sort((a, b) => b.points - a.points);
    
    // Mark top 6 as counting
    const countingScores = Math.min(6, sortedByPoints.length);
    const countingEventIds = new Set(sortedByPoints.slice(0, 6).map(s => s.event_id));
    
    // Update counting flag in original scores
    for (const score of data.scores) {
      score.counting = countingEventIds.has(score.event_id);
    }
    
    // Sum best 6
    const totalPoints = sortedByPoints
      .slice(0, 6)
      .reduce((sum, s) => sum + s.points, 0);
    
    // Sort by date for display
    const scoresByDate = [...data.scores].sort((a, b) => 
      new Date(a.event_date).getTime() - new Date(b.event_date).getTime()
    );

    return {
      member_id: memberId,
      name: data.name,
      handicap: data.handicap,
      total_points: totalPoints,
      events_played: data.scores.length,
      counting_events: countingScores,
      best_score: sortedByPoints[0]?.points || 0,
      breakdown: scoresByDate,
    };
  });

  // Sort by total points descending, then best score as tiebreaker
  standings.sort((a, b) => {
    if (a.total_points !== b.total_points) return b.total_points - a.total_points;
    return b.best_score - a.best_score;
  });

  // Add positions and limit
  const topStandings = standings.slice(0, limit).map((entry, index) => ({
    position: index + 1,
    ...entry,
  }));

  return NextResponse.json({ 
    season: seasonYear.toString(), 
    standings: topStandings,
    total_events: events.length,
    rules: 'Best 6 of 8 Stableford scores'
  });
}
