import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  await seedDatabase();
  const db = getDb();

  const { searchParams } = new URL(request.url);
  const division = searchParams.get('division') || 'all';

  const seasonResult = await db.execute("SELECT * FROM seasons WHERE status = 'active' ORDER BY year DESC LIMIT 1");
  const season = seasonResult.rows[0] as Record<string, unknown> | undefined;
  if (!season) return NextResponse.json({ standings: [], season: null });

  const seasonId = season.id as string;
  const eventsCompleteResult = await db.execute({
    sql: `SELECT COUNT(*) as c FROM events WHERE season_id = ? AND status = 'finalised'`,
    args: [seasonId]
  });
  const eventsComplete = Number(eventsCompleteResult.rows[0]?.c) || 0;

  let query = `
    SELECT ss.*, m.name, m.handicap, m.member_type
    FROM season_standings ss
    JOIN members m ON m.id = ss.member_id
    WHERE ss.season_id = ?
  `;

  if (division === 'div_a') {
    query += ' AND m.handicap <= 14';
  } else if (division === 'div_b') {
    query += ' AND m.handicap >= 15';
  }

  query += ' ORDER BY ss.total_points DESC, ss.best_finish ASC, ss.avg_score DESC';

  const standingsResult = await db.execute({ sql: query, args: [seasonId] });
  const standings = standingsResult.rows as unknown as Array<Record<string, unknown>>;

  // Re-rank for filtered division
  const ranked = standings.map((s, idx) => ({
    ...s,
    display_position: idx + 1,
    counting_events: s.counting_events ? JSON.parse(s.counting_events as string) : [],
  }));

  // Points table
  const pointsTable = [
    { position: 1, points: 25 },
    { position: 2, points: 18 },
    { position: 3, points: 15 },
    { position: 4, points: 12 },
    { position: 5, points: 10 },
    { position: 6, points: 8 },
    { position: 7, points: 6 },
    { position: 8, points: 4 },
    { position: 9, points: 2 },
    { position: 10, points: 1 },
  ];

  return NextResponse.json({
    standings: ranked,
    season: {
      ...season,
      events_complete: eventsComplete,
      bonus_config: season.bonus_config ? JSON.parse(season.bonus_config as string) : null,
    },
    points_table: pointsTable,
  });
}
