import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export const dynamic = 'force-dynamic';

export async function GET() {
  await seedDatabase();
  const db = getDb();

  const seasonResult = await db.execute(`
    SELECT s.*, 
      (SELECT COUNT(*) FROM events WHERE season_id = s.id AND (status = 'finalised' OR results_published = 1)) as events_complete,
      (SELECT COUNT(*) FROM events WHERE season_id = s.id) as events_total
    FROM seasons s WHERE s.status = 'active' ORDER BY s.year DESC LIMIT 1
  `);
  const season = seasonResult.rows[0] as Record<string, unknown> | undefined;

  if (!season) return NextResponse.json(null);

  return NextResponse.json({
    ...season,
    bonus_config: season.bonus_config ? JSON.parse(season.bonus_config as string) : null,
    custom_points: season.custom_points ? JSON.parse(season.custom_points as string) : null,
  });
}
