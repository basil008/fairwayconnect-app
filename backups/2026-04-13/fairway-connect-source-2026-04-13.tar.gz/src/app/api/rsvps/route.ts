import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';
import { v4 as uuidv4 } from 'uuid';

async function getCurrentEventId(db: ReturnType<typeof getDb>): Promise<string | undefined> {
  // in_progress first, then next upcoming, then most recently finalised
  const inProgressResult = await db.execute("SELECT id FROM events WHERE status = 'in_progress' ORDER BY date ASC LIMIT 1");
  if (inProgressResult.rows[0]?.id) return inProgressResult.rows[0].id as string;

  const upcomingResult = await db.execute("SELECT id FROM events WHERE status = 'upcoming' ORDER BY date ASC LIMIT 1");
  if (upcomingResult.rows[0]?.id) return upcomingResult.rows[0].id as string;

  const finalisedResult = await db.execute("SELECT id FROM events WHERE status = 'finalised' ORDER BY date DESC LIMIT 1");
  if (finalisedResult.rows[0]?.id) return finalisedResult.rows[0].id as string;

  return undefined;
}

export async function GET(request: Request) {
  await seedDatabase();
  const db = getDb();
  
  // Ensure can_enter_scores column exists
  try {
    await db.execute(`ALTER TABLE rsvps ADD COLUMN can_enter_scores INTEGER DEFAULT 1`);
  } catch {
    // Column already exists
  }
  
  const url = new URL(request.url);
  const eventId = url.searchParams.get('event_id') || await getCurrentEventId(db);
  if (!eventId) return NextResponse.json([]);

  const rsvpsResult = await db.execute({
    sql: `
      SELECT r.id, r.event_id, r.member_id, r.status, r.can_enter_scores, r.created_at,
             r.payment_status, r.payment_amount, r.payment_date,
             r.greenfee_status, r.prize_paid,
             m.name, m.handicap, m.member_type
      FROM rsvps r JOIN members m ON m.id = r.member_id
      WHERE r.event_id = ?
    `,
    args: [eventId]
  });
  
  // Sort by status first, then by surname (last word of name)
  const getSurname = (name: string) => {
    const parts = (name || '').trim().split(/\s+/);
    return parts[parts.length - 1].toLowerCase();
  };
  const statusOrder: Record<string, number> = { confirmed: 0, maybe: 1, declined: 2 };
  const rsvps = rsvpsResult.rows.sort((a, b) => {
    const statusA = statusOrder[a.status as string] ?? 3;
    const statusB = statusOrder[b.status as string] ?? 3;
    if (statusA !== statusB) return statusA - statusB;
    return getSurname(a.name as string).localeCompare(getSurname(b.name as string));
  });
  
  return NextResponse.json(rsvps);
}

export async function POST(request: Request) {
  const db = getDb();
  const { event_id, member_id, status } = await request.json();

  const existingResult = await db.execute({
    sql: 'SELECT id FROM rsvps WHERE event_id = ? AND member_id = ?',
    args: [event_id, member_id]
  });
  const existing = existingResult.rows[0] as unknown as { id: string } | undefined;

  if (existing) {
    await db.execute({ sql: 'UPDATE rsvps SET status = ? WHERE id = ?', args: [status, existing.id] });
  } else {
    await db.execute({
      sql: 'INSERT INTO rsvps (id, event_id, member_id, status) VALUES (?, ?, ?, ?)',
      args: [uuidv4(), event_id, member_id, status]
    });
  }

  return NextResponse.json({ success: true });
}

export async function PUT(request: Request) {
  const db = getDb();
  const body = await request.json();
  const { rsvp_id } = body;

  // Handle can_enter_scores update
  if ('can_enter_scores' in body) {
    await db.execute({
      sql: 'UPDATE rsvps SET can_enter_scores = ? WHERE id = ?',
      args: [body.can_enter_scores ? 1 : 0, rsvp_id]
    });
  }

  // Handle payment status update (legacy)
  if ('payment_status' in body) {
    await db.execute({
      sql: 'UPDATE rsvps SET payment_status = ?, payment_date = ? WHERE id = ?',
      args: [body.payment_status, body.payment_date || null, rsvp_id]
    });
  }

  // Handle green fee status
  if ('greenfee_status' in body) {
    await db.execute({
      sql: 'UPDATE rsvps SET greenfee_status = ? WHERE id = ?',
      args: [body.greenfee_status, rsvp_id]
    });
  }

  // Handle prize paid
  if ('prize_paid' in body) {
    await db.execute({
      sql: 'UPDATE rsvps SET prize_paid = ? WHERE id = ?',
      args: [body.prize_paid ? 1 : 0, rsvp_id]
    });
  }

  return NextResponse.json({ success: true });
}

export async function DELETE(request: Request) {
  const db = getDb();
  const { rsvp_id, event_id } = await request.json();

  // Delete the RSVP
  await db.execute({ sql: 'DELETE FROM rsvps WHERE id = ?', args: [rsvp_id] });

  // Also remove from tee times if present
  if (event_id) {
    const rsvpResult = await db.execute({ sql: 'SELECT member_id FROM rsvps WHERE id = ?', args: [rsvp_id] });
    const memberId = rsvpResult.rows[0]?.member_id;
    
    if (memberId) {
      const teeTimesResult = await db.execute({ sql: 'SELECT id, member_ids FROM tee_times WHERE event_id = ?', args: [event_id] });
      for (const tt of teeTimesResult.rows) {
        const memberIds = JSON.parse((tt.member_ids as string) || '[]');
        const filtered = memberIds.filter((id: string) => id !== memberId);
        if (filtered.length !== memberIds.length) {
          await db.execute({ sql: 'UPDATE tee_times SET member_ids = ? WHERE id = ?', args: [JSON.stringify(filtered), tt.id] });
        }
      }
    }
  }

  return NextResponse.json({ success: true });
}
