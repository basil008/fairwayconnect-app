import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export const dynamic = 'force-dynamic';

export async function GET() {
  await seedDatabase();
  const client = getDb();

  const seasonResult = await client.execute("SELECT * FROM seasons WHERE status = 'active' ORDER BY year DESC LIMIT 1");
  const season = seasonResult.rows[0];
  if (!season) return NextResponse.json({ events: [], season: null });

  const seasonId = season.id as string;

  const eventsResult = await client.execute({
    sql: `SELECT e.*,
      (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'confirmed') as confirmed_count,
      (SELECT m.name FROM prize_allocations pa JOIN members m ON m.id = pa.member_id
       WHERE pa.event_id = e.id AND pa.prize_type IN ('overall','class_1') AND pa.position = 1 LIMIT 1) as winner_name,
      (SELECT pa.label FROM prize_allocations pa
       WHERE pa.event_id = e.id AND pa.prize_type IN ('overall','class_1') AND pa.position = 1 LIMIT 1) as winner_label
    FROM events e
    WHERE e.season_id = ?
    ORDER BY e.event_number`,
    args: [seasonId]
  });
  const events = eventsResult.rows as unknown as Array<Record<string, unknown>>;

  const eventsComplete = events.filter(e => e.status === 'finalised' || e.results_published === 1).length;

  return NextResponse.json({
    events: events.map(e => ({
      ...e,
      prize_config: e.prize_config ? JSON.parse(e.prize_config as string) : null,
    })),
    season: {
      ...season,
      events_complete: eventsComplete,
      bonus_config: season.bonus_config ? JSON.parse(season.bonus_config as string) : null,
    },
  });
}
