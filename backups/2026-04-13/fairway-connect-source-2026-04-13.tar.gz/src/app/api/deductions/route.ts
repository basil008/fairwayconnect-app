import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

export const dynamic = 'force-dynamic';

// Ensure table exists
async function ensureTable() {
  const db = getDb();
  await db.execute(`
    CREATE TABLE IF NOT EXISTS member_deductions (
      id TEXT PRIMARY KEY,
      member_name TEXT NOT NULL,
      first_name TEXT,
      year INTEGER NOT NULL,
      year_starting_deduction INTEGER DEFAULT 0,
      outing_1 INTEGER DEFAULT 0,
      outing_2 INTEGER DEFAULT 0,
      outing_3 INTEGER DEFAULT 0,
      outing_4 INTEGER DEFAULT 0,
      outing_5 INTEGER DEFAULT 0,
      outing_6 INTEGER DEFAULT 0,
      outing_7 INTEGER DEFAULT 0,
      outing_8 INTEGER DEFAULT 0,
      UNIQUE(member_name, first_name, year)
    )
  `);
}

export async function GET(request: Request) {
  await ensureTable();
  const db = getDb();
  const { searchParams } = new URL(request.url);
  const year = searchParams.get('year') || new Date().getFullYear().toString();

  const result = await db.execute({
    sql: `SELECT * FROM member_deductions WHERE year = ? ORDER BY (year_starting_deduction + outing_1 + outing_2 + outing_3 + outing_4 + outing_5 + outing_6 + outing_7 + outing_8) ASC, member_name ASC, first_name ASC`,
    args: [parseInt(year)]
  });

  const deductions = result.rows.map(row => ({
    ...row,
    current_deductions: (row.year_starting_deduction as number || 0) +
      (row.outing_1 as number || 0) + (row.outing_2 as number || 0) +
      (row.outing_3 as number || 0) + (row.outing_4 as number || 0) +
      (row.outing_5 as number || 0) + (row.outing_6 as number || 0) +
      (row.outing_7 as number || 0) + (row.outing_8 as number || 0)
  }));

  return NextResponse.json({ deductions, year: parseInt(year) });
}

export async function POST(request: Request) {
  await ensureTable();
  const db = getDb();
  const body = await request.json();

  if (body.action === 'import') {
    // Bulk import from Excel data
    const { data, year } = body;
    for (const row of data) {
      await db.execute({
        sql: `INSERT OR REPLACE INTO member_deductions 
          (id, member_name, first_name, year, year_starting_deduction, outing_1, outing_2, outing_3, outing_4, outing_5, outing_6, outing_7, outing_8)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        args: [
          uuidv4(), row.member_name, row.first_name || '', year,
          row.year_starting_deduction || 0,
          row.outing_1 || 0, row.outing_2 || 0, row.outing_3 || 0, row.outing_4 || 0,
          row.outing_5 || 0, row.outing_6 || 0, row.outing_7 || 0, row.outing_8 || 0
        ]
      });
    }
    return NextResponse.json({ success: true, imported: data.length });
  }

  if (body.action === 'update') {
    // Update a single cell
    const { id, field, value } = body;
    const allowedFields = ['year_starting_deduction', 'outing_1', 'outing_2', 'outing_3', 'outing_4', 'outing_5', 'outing_6', 'outing_7', 'outing_8'];
    if (!allowedFields.includes(field)) {
      return NextResponse.json({ error: 'Invalid field' }, { status: 400 });
    }
    await db.execute({
      sql: `UPDATE member_deductions SET ${field} = ? WHERE id = ?`,
      args: [value, id]
    });
    return NextResponse.json({ success: true });
  }

  if (body.action === 'add') {
    // Add new member
    const { member_name, first_name, year } = body;
    await db.execute({
      sql: `INSERT INTO member_deductions (id, member_name, first_name, year) VALUES (?, ?, ?, ?)`,
      args: [uuidv4(), member_name, first_name || '', year]
    });
    return NextResponse.json({ success: true });
  }

  return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
}
