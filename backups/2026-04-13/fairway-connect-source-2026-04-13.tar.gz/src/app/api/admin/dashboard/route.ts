import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export const dynamic = 'force-dynamic';

export async function GET() {
  await seedDatabase();
  const db = getDb();

  // Get season info
  const seasonResult = await db.execute("SELECT * FROM seasons WHERE status = 'active' ORDER BY year DESC LIMIT 1");
  const season = seasonResult.rows[0] as Record<string, unknown> | undefined;
  const seasonId = (season?.id as string) || '';

  const eventsCompleteResult = await db.execute({ 
    sql: `SELECT COUNT(*) as c FROM events WHERE season_id = ? AND (status = 'finalised')`,
    args: [seasonId]
  });
  const eventsComplete = Number(eventsCompleteResult.rows[0]?.c) || 0;

  const totalEventsResult = await db.execute({
    sql: `SELECT COUNT(*) as c FROM events WHERE season_id = ?`,
    args: [seasonId]
  });
  const totalEvents = Number(totalEventsResult.rows[0]?.c) || 0;

  // Current/next event
  let currentEventResult = await db.execute({
    sql: `
      SELECT e.*, 
        (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'confirmed') as confirmed_count,
        (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'maybe') as maybe_count,
        (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'declined') as declined_count,
        (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id) as total_rsvps,
        (SELECT COUNT(*) FROM scorecards WHERE event_id = e.id AND status = 'submitted') as submitted_count,
        (SELECT COUNT(*) FROM scorecards WHERE event_id = e.id) as total_scorecards
      FROM events e
      WHERE e.season_id = ? AND e.status = 'in_progress'
      ORDER BY e.date ASC LIMIT 1
    `,
    args: [seasonId]
  });
  let currentEvent = currentEventResult.rows[0] as Record<string, unknown> | null;

  if (!currentEvent) {
    const upcomingEventResult = await db.execute({
      sql: `
        SELECT e.*, 
          (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'confirmed') as confirmed_count,
          (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'maybe') as maybe_count,
          (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'declined') as declined_count,
          (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id) as total_rsvps,
          (SELECT COUNT(*) FROM scorecards WHERE event_id = e.id AND status = 'submitted') as submitted_count,
          (SELECT COUNT(*) FROM scorecards WHERE event_id = e.id) as total_scorecards
        FROM events e
        WHERE e.season_id = ? AND e.status = 'upcoming'
        ORDER BY e.date ASC LIMIT 1
      `,
      args: [seasonId]
    });
    currentEvent = upcomingEventResult.rows[0] as Record<string, unknown> | null;
  }

  // Fallback: show most recent finalised event if no upcoming/in_progress
  if (!currentEvent) {
    const lastEventResult = await db.execute({
      sql: `
        SELECT e.*, 
          (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'confirmed') as confirmed_count,
          (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'maybe') as maybe_count,
          (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id AND status = 'declined') as declined_count,
          (SELECT COUNT(*) FROM rsvps WHERE event_id = e.id) as total_rsvps,
          (SELECT COUNT(*) FROM scorecards WHERE event_id = e.id AND status = 'submitted') as submitted_count,
          (SELECT COUNT(*) FROM scorecards WHERE event_id = e.id) as total_scorecards
        FROM events e
        WHERE e.season_id = ?
        ORDER BY e.date DESC LIMIT 1
      `,
      args: [seasonId]
    });
    currentEvent = lastEventResult.rows[0] as Record<string, unknown> | null;
  }

  // Total members
  const totalMembersResult = await db.execute("SELECT COUNT(*) as c FROM members WHERE member_type = 'member' AND status = 'active'");
  const totalMembers = Number(totalMembersResult.rows[0]?.c) || 0;

  // Revenue summary
  const totalCollectedResult = await db.execute({
    sql: `
      SELECT COALESCE(SUM(e.entry_fee * (SELECT COUNT(*) FROM rsvps r WHERE r.event_id = e.id AND r.status = 'confirmed')), 0) as total
      FROM events e WHERE e.season_id = ? AND (e.status = 'finalised' OR e.status = 'in_progress')
    `,
    args: [seasonId]
  });
  const totalCollected = Number(totalCollectedResult.rows[0]?.total) || 0;

  const totalOutstandingResult = await db.execute({
    sql: `
      SELECT COALESCE(SUM(e.entry_fee * (SELECT COUNT(*) FROM rsvps r WHERE r.event_id = e.id AND r.status = 'confirmed')), 0) as total
      FROM events e WHERE e.season_id = ? AND e.status = 'upcoming'
    `,
    args: [seasonId]
  });
  const totalOutstanding = Number(totalOutstandingResult.rows[0]?.total) || 0;

  // GOTY leader — best 6 of 8 Stableford scores from finalised + in_progress events
  const gotyEventsResult = await db.execute({
    sql: `SELECT id FROM events WHERE season_id = ? AND status IN ('finalised', 'in_progress')`,
    args: [seasonId]
  });
  let oomLeader: Record<string, unknown> | null = null;
  if (gotyEventsResult.rows.length > 0) {
    const eventIds = gotyEventsResult.rows.map(r => r.id as string);
    // Get all submitted scorecards grouped by member, sum best 6
    const gotyResult = await db.execute({
      sql: `SELECT m.name, SUM(sc.total_points) as total_points, COUNT(*) as events_played
            FROM scorecards sc JOIN members m ON m.id = sc.member_id
            WHERE sc.event_id IN (${eventIds.map(() => '?').join(',')}) AND sc.status = 'submitted' AND m.member_type != 'visitor'
            GROUP BY m.id, m.name ORDER BY total_points DESC LIMIT 1`,
      args: eventIds
    });
    if (gotyResult.rows.length > 0) {
      oomLeader = gotyResult.rows[0] as Record<string, unknown>;
    }
  }

  // Alerts
  const alerts: Array<{ type: string; message: string; link?: string }> = [];

  if (currentEvent && currentEvent.status === 'upcoming') {
    const noResponse = totalMembers - (Number(currentEvent.total_rsvps) || 0);
    if (noResponse > 0) {
      alerts.push({
        type: 'warning',
        message: `${noResponse} members haven't RSVPd for ${currentEvent.name}`,
        link: `/admin/event/${currentEvent.id}`,
      });
    }
  }

  // Last finalised event
  const lastFinalisedResult = await db.execute({
    sql: `
      SELECT e.name FROM events e
      WHERE e.season_id = ? AND e.status = 'finalised'
      ORDER BY e.date DESC LIMIT 1
    `,
    args: [seasonId]
  });
  const lastFinalised = lastFinalisedResult.rows[0] as Record<string, unknown> | null;

  if (lastFinalised) {
    alerts.push({
      type: 'success',
      message: `${lastFinalised.name} results published`,
    });
  }

  return NextResponse.json({
    season: season ? { ...season, events_complete: eventsComplete, total_events: totalEvents } : null,
    currentEvent,
    totalMembers,
    revenue: { collected: totalCollected, outstanding: totalOutstanding },
    oomLeader,
    alerts,
  });
}
