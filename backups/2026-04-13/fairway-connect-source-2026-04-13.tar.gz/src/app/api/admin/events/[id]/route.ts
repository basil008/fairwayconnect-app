import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export const dynamic = 'force-dynamic';

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  await seedDatabase();
  const db = getDb();
  const { id } = await params;

  const eventResult = await db.execute({ sql: 'SELECT * FROM events WHERE id = ?', args: [id] });
  const event = eventResult.rows[0] as Record<string, unknown> | undefined;
  if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 });

  const holesResult = await db.execute({ sql: 'SELECT * FROM course_holes WHERE event_id = ? ORDER BY hole_number', args: [id] });
  const holes = holesResult.rows;

  const rsvpsResult = await db.execute({
    sql: `
      SELECT r.*, m.name, m.handicap, m.member_type, m.email, m.phone
      FROM rsvps r JOIN members m ON m.id = r.member_id
      WHERE r.event_id = ?
      ORDER BY r.status, m.name
    `,
    args: [id]
  });
  const rsvps = rsvpsResult.rows;

  const teeTimesResult = await db.execute({ sql: 'SELECT * FROM tee_times WHERE event_id = ? ORDER BY group_number', args: [id] });
  const teeTimes = teeTimesResult.rows as unknown as Array<{
    id: string; group_number: number; tee_time: string; member_ids: string;
  }>;
  const teeTimesWithMembers = await Promise.all(teeTimes.map(async (tt) => {
    const memberIds = JSON.parse(tt.member_ids) as string[];
    const members = await Promise.all(memberIds.map(async (mid) => {
      const memberResult = await db.execute({ sql: 'SELECT id, name, handicap FROM members WHERE id = ?', args: [mid] });
      return memberResult.rows[0];
    }));
    return { ...tt, members: members.filter(Boolean) };
  }));

  const scorecardsResult = await db.execute({
    sql: `
      SELECT s.*, m.name, m.handicap, m.member_type,
        (SELECT COUNT(*) FROM hole_scores WHERE scorecard_id = s.id) as holes_completed
      FROM scorecards s JOIN members m ON m.id = s.member_id
      WHERE s.event_id = ?
      ORDER BY s.total_points DESC, s.total_gross ASC
    `,
    args: [id]
  });
  const scorecards = scorecardsResult.rows;

  const sideCompsResult = await db.execute({
    sql: `
      SELECT sc.*, m.name as member_name
      FROM side_comps sc JOIN members m ON m.id = sc.member_id
      WHERE sc.event_id = ?
      ORDER BY sc.type, sc.hole_number
    `,
    args: [id]
  });
  const sideComps = sideCompsResult.rows;

  const prizesResult = await db.execute({
    sql: `
      SELECT pa.*, m.name as member_name
      FROM prize_allocations pa JOIN members m ON m.id = pa.member_id
      WHERE pa.event_id = ?
      ORDER BY CASE pa.prize_type
        WHEN 'overall' THEN 1 WHEN 'division_a' THEN 2 WHEN 'division_b' THEN 3
        WHEN 'best_visitor' THEN 4 WHEN 'ntp' THEN 5 WHEN 'longest_drive' THEN 6 END,
        pa.position
    `,
    args: [id]
  });
  const prizes = prizesResult.rows;

  return NextResponse.json({
    event: { ...event, prize_config: event.prize_config ? JSON.parse(event.prize_config as string) : null },
    holes,
    rsvps,
    teeTimes: teeTimesWithMembers,
    scorecards,
    sideComps,
    prizes,
  });
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  await seedDatabase();
  const db = getDb();
  const { id } = await params;
  const body = await request.json();

  if (body.action === 'update_status') {
    await db.execute({ sql: 'UPDATE events SET status = ? WHERE id = ?', args: [body.status, id] });
    return NextResponse.json({ success: true });
  }

  if (body.action === 'update_details') {
    await db.execute({
      sql: `
        UPDATE events SET name = ?, course_name = ?, location = ?, date = ?, first_tee = ?,
          format = ?, entry_fee = ?, prize_fund = ?, notes = ?, prize_config = ?,
          slope_rating = ?, course_rating = ?, course_par = ?, handicap_allowance = ?,
          course_id = ?, selected_tee_id = ?,
          tee_interval = ?,
          event_type = ?, class1_max_handicap = ?, class2_min_handicap = ?,
          club_contact_name = ?, club_contact_phone = ?, club_contact_email = ?,
          booking_notes = ?, deposit_amount = ?, deposit_paid_by = ?, deposit_paid_date = ?,
          booked_by = ?, booked_date = ?
        WHERE id = ?
      `,
      args: [
        body.name, body.course_name, body.location, body.date, body.first_tee,
        body.format, body.entry_fee, body.prize_fund, body.notes,
        body.prize_config ? JSON.stringify(body.prize_config) : null,
        body.slope_rating || 113, body.course_rating || 72, body.course_par || 72, body.handicap_allowance || 0.95,
        body.course_id || null, body.selected_tee_id || null,
        body.tee_interval || 10,
        body.event_type || 'standard', body.class1_max_handicap || 18, body.class2_min_handicap || 19,
        body.club_contact_name || null, body.club_contact_phone || null, body.club_contact_email || null,
        body.booking_notes || null, body.deposit_amount || 0, body.deposit_paid_by || null, body.deposit_paid_date || null,
        body.booked_by || null, body.booked_date || null,
        id
      ]
    });
    return NextResponse.json({ success: true });
  }

  return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  await seedDatabase();
  const db = getDb();
  const { id } = await params;

  // Delete all related data first (foreign key constraints)
  await db.execute({ sql: 'DELETE FROM hole_scores WHERE scorecard_id IN (SELECT id FROM scorecards WHERE event_id = ?)', args: [id] });
  await db.execute({ sql: 'DELETE FROM scorecards WHERE event_id = ?', args: [id] });
  await db.execute({ sql: 'DELETE FROM rsvps WHERE event_id = ?', args: [id] });
  await db.execute({ sql: 'DELETE FROM tee_times WHERE event_id = ?', args: [id] });
  await db.execute({ sql: 'DELETE FROM course_holes WHERE event_id = ?', args: [id] });
  await db.execute({ sql: 'DELETE FROM side_comps WHERE event_id = ?', args: [id] });
  await db.execute({ sql: 'DELETE FROM prize_allocations WHERE event_id = ?', args: [id] });
  await db.execute({ sql: 'DELETE FROM activity_log WHERE event_id = ?', args: [id] });
  
  // Finally delete the event itself
  await db.execute({ sql: 'DELETE FROM events WHERE id = ?', args: [id] });

  return NextResponse.json({ success: true });
}
