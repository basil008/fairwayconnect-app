import { createClient, type Client } from '@libsql/client/web';

// In serverless, create fresh client each time to avoid stale connections
export function getDb(): Client {
  const url = process.env.TURSO_DATABASE_URL;
  const authToken = process.env.TURSO_AUTH_TOKEN;
  
  if (!url) {
    throw new Error('TURSO_DATABASE_URL environment variable is not set');
  }
  
  return createClient({
    url,
    authToken: authToken || undefined,
  });
}

export async function initializeDb() {
  const client = getDb();
  
  // Execute schema creation statements individually
  const statements = [
    `CREATE TABLE IF NOT EXISTS societies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      logo TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    )`,
    
    `CREATE TABLE IF NOT EXISTS society_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )`,
    
    `CREATE TABLE IF NOT EXISTS members (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL,
      name TEXT NOT NULL,
      handicap INTEGER NOT NULL,
      email TEXT,
      phone TEXT,
      member_type TEXT DEFAULT 'member',
      status TEXT DEFAULT 'active',
      joined_date TEXT DEFAULT (date('now')),
      created_at TEXT DEFAULT (datetime('now')),
      access_token TEXT UNIQUE,
      member_pin TEXT UNIQUE,
      FOREIGN KEY (society_id) REFERENCES societies(id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS seasons (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL,
      name TEXT NOT NULL,
      year INTEGER NOT NULL,
      start_date TEXT,
      end_date TEXT,
      points_system TEXT DEFAULT 'f1',
      best_of_x INTEGER DEFAULT 0,
      total_events INTEGER DEFAULT 0,
      custom_points TEXT,
      bonus_config TEXT,
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT (datetime('now'))
    )`,
    
    `CREATE TABLE IF NOT EXISTS events (
      id TEXT PRIMARY KEY,
      society_id TEXT NOT NULL,
      name TEXT NOT NULL,
      course_name TEXT NOT NULL,
      date TEXT NOT NULL,
      format TEXT NOT NULL,
      entry_fee REAL,
      first_tee TEXT,
      status TEXT DEFAULT 'upcoming',
      prize_config TEXT,
      season_id TEXT,
      event_number INTEGER,
      location TEXT,
      notes TEXT,
      prize_fund REAL,
      results_published INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (society_id) REFERENCES societies(id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS course_holes (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL,
      hole_number INTEGER NOT NULL,
      par INTEGER NOT NULL,
      stroke_index INTEGER NOT NULL,
      yardage INTEGER NOT NULL,
      FOREIGN KEY (event_id) REFERENCES events(id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS rsvps (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL,
      member_id TEXT NOT NULL,
      status TEXT NOT NULL,
      can_enter_scores INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (event_id) REFERENCES events(id),
      FOREIGN KEY (member_id) REFERENCES members(id),
      UNIQUE(event_id, member_id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS tee_times (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL,
      group_number INTEGER NOT NULL,
      tee_time TEXT NOT NULL,
      member_ids TEXT NOT NULL,
      FOREIGN KEY (event_id) REFERENCES events(id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS scorecards (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL,
      member_id TEXT NOT NULL,
      status TEXT DEFAULT 'in_progress',
      total_gross INTEGER,
      total_points INTEGER,
      submitted_at TEXT,
      entry_method TEXT DEFAULT 'manual',
      scan_image_path TEXT,
      FOREIGN KEY (event_id) REFERENCES events(id),
      FOREIGN KEY (member_id) REFERENCES members(id),
      UNIQUE(event_id, member_id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS hole_scores (
      id TEXT PRIMARY KEY,
      scorecard_id TEXT NOT NULL,
      hole_number INTEGER NOT NULL,
      gross_score INTEGER NOT NULL,
      stableford_points INTEGER NOT NULL,
      FOREIGN KEY (scorecard_id) REFERENCES scorecards(id),
      UNIQUE(scorecard_id, hole_number)
    )`,
    
    `CREATE TABLE IF NOT EXISTS side_comps (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL,
      type TEXT NOT NULL,
      hole_number INTEGER,
      member_id TEXT NOT NULL,
      value REAL NOT NULL,
      unit TEXT,
      FOREIGN KEY (event_id) REFERENCES events(id),
      FOREIGN KEY (member_id) REFERENCES members(id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS prize_allocations (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL,
      member_id TEXT NOT NULL,
      prize_type TEXT NOT NULL,
      position INTEGER,
      label TEXT NOT NULL,
      value REAL,
      countback_note TEXT,
      FOREIGN KEY (event_id) REFERENCES events(id),
      FOREIGN KEY (member_id) REFERENCES members(id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS activity_log (
      id TEXT PRIMARY KEY,
      event_id TEXT,
      member_id TEXT,
      action TEXT NOT NULL,
      detail TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    )`,
    
    `CREATE TABLE IF NOT EXISTS season_standings (
      id TEXT PRIMARY KEY,
      season_id TEXT NOT NULL,
      member_id TEXT NOT NULL,
      total_points REAL DEFAULT 0,
      events_played INTEGER DEFAULT 0,
      best_finish INTEGER DEFAULT 99,
      wins INTEGER DEFAULT 0,
      top_3 INTEGER DEFAULT 0,
      avg_score REAL DEFAULT 0,
      best_score INTEGER DEFAULT 0,
      ntp_wins INTEGER DEFAULT 0,
      ld_wins INTEGER DEFAULT 0,
      position INTEGER DEFAULT 0,
      prev_position INTEGER DEFAULT 0,
      counting_events TEXT,
      UNIQUE(season_id, member_id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS player_event_stats (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL,
      member_id TEXT NOT NULL,
      position INTEGER,
      points_earned REAL DEFAULT 0,
      stableford_total INTEGER DEFAULT 0,
      gross_total INTEGER DEFAULT 0,
      handicap_at_event INTEGER,
      prizes_won TEXT,
      UNIQUE(event_id, member_id)
    )`,
    
    `CREATE TABLE IF NOT EXISTS goty_points (
      id TEXT PRIMARY KEY,
      member_id TEXT NOT NULL,
      event_id TEXT NOT NULL,
      position TEXT NOT NULL,
      points INTEGER NOT NULL,
      season TEXT NOT NULL,
      FOREIGN KEY (member_id) REFERENCES members(id),
      FOREIGN KEY (event_id) REFERENCES events(id),
      UNIQUE(event_id, member_id)
    )`
  ];
  
  // Execute each statement individually
  for (const statement of statements) {
    await client.execute(statement);
  }
  
  // Migrations for existing databases
  try {
    await client.execute(`ALTER TABLE rsvps ADD COLUMN can_enter_scores INTEGER DEFAULT 1`);
  } catch {
    // Column already exists
  }
}
// Add deductions table - run this migration
export async function migrateDeductions() {
  const client = getDb();
  await client.execute(`
    CREATE TABLE IF NOT EXISTS member_deductions (
      id TEXT PRIMARY KEY,
      member_name TEXT NOT NULL,
      first_name TEXT,
      year INTEGER NOT NULL,
      year_starting_deduction INTEGER DEFAULT 0,
      outing_1 INTEGER DEFAULT 0,
      outing_2 INTEGER DEFAULT 0,
      outing_3 INTEGER DEFAULT 0,
      outing_4 INTEGER DEFAULT 0,
      outing_5 INTEGER DEFAULT 0,
      outing_6 INTEGER DEFAULT 0,
      outing_7 INTEGER DEFAULT 0,
      outing_8 INTEGER DEFAULT 0,
      UNIQUE(member_name, first_name, year)
    )
  `);

  // Add base_handicap column if not exists (stores Golf Ireland handicap, never mutated)
  try {
    await client.execute('ALTER TABLE members ADD COLUMN base_handicap REAL');
  } catch { /* column already exists */ }

  // Copy current handicap to base_handicap where base_handicap is null
  await client.execute('UPDATE members SET base_handicap = handicap WHERE base_handicap IS NULL');
}
