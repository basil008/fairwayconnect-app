import { getDb, initializeDb } from './db';
import { calculateStablefordPoints } from './stableford';
import { v4 as uuidv4 } from 'uuid';

const SOCIETY_ID = 'soc_oscar_001';
const SEASON_ID = 'season_2026';
const EVENT_ID = 'evt_spring_classic_001';

function generateAccessToken(name: string, usedTokens: Set<string>): string {
  // Generate a memorable token from first letter of first name + first 2 letters of surname + 3 random alphanumeric
  const parts = name.replace(/['']/g, '').split(/\s+/);
  const first = parts[0] || '';
  const last = parts[parts.length - 1] || '';
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  
  let token: string;
  do {
    const prefix = (first[0] || 'x').toLowerCase() + (last.slice(0, 2) || 'xx').charAt(0).toUpperCase() + (last.slice(1, 2) || 'x').toLowerCase();
    const suffix = Array.from({ length: 3 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    token = prefix + suffix;
  } while (usedTokens.has(token));
  usedTokens.add(token);
  return token;
}

const MEMBERS: Array<{ name: string; handicap: number; type?: string }> = [
  { name: 'Séamus O\'Brien', handicap: 5 },
  { name: 'Pádraig Murphy', handicap: 8 },
  { name: 'Ciarán Kelly', handicap: 12 },
  { name: 'Declan Walsh', handicap: 4 },
  { name: 'Niall Fitzgerald', handicap: 15 },
  { name: 'Conor Byrne', handicap: 18 },
  { name: 'Eoin Ryan', handicap: 7 },
  { name: 'Brendan Doyle', handicap: 22 },
  { name: 'Dermot Kavanagh', handicap: 11 },
  { name: 'Oisín McCarthy', handicap: 16 },
  { name: 'Tadhg O\'Sullivan', handicap: 9 },
  { name: 'Colm Brennan', handicap: 25 },
  { name: 'Fergal Dunne', handicap: 14 },
  { name: 'Liam Nolan', handicap: 20 },
  { name: 'Ronan Gallagher', handicap: 6 },
  { name: 'Cathal Moran', handicap: 28 },
  { name: 'Shane Connolly', handicap: 10 },
  { name: 'Barry Healy', handicap: 17 },
  { name: 'Donal O\'Connor', handicap: 13 },
  { name: 'Micheál Flanagan', handicap: 23 },
  { name: 'Kevin Power', handicap: 8 },
  { name: 'Tommy Dempsey', handicap: 19 },
  { name: 'Aidan Lynch', handicap: 11 },
  { name: 'Fintan O\'Reilly', handicap: 26 },
  { name: 'Darren Keane', handicap: 7 },
  { name: 'Noel Buckley', handicap: 21 },
  { name: 'Gareth Sweeney', handicap: 15 },
  { name: 'Patrick Maguire', handicap: 4 },
  { name: 'James O\'Neill', handicap: 24 },
  { name: 'Martin Tierney', handicap: 12 },
  { name: 'Alan Foley', handicap: 16 },
  { name: 'Brian Regan', handicap: 9 },
  { name: 'Frank Whelan', handicap: 27 },
  { name: 'Hugh Delaney', handicap: 6 },
  { name: 'Cormac Quinn', handicap: 18 },
  { name: 'Damien Lawlor', handicap: 14 },
  { name: 'Rory Hennessy', handicap: 20 },
  { name: 'Diarmuid Casey', handicap: 10 },
  { name: 'Peadar Molloy', handicap: 22 },
  { name: 'Seán Burke', handicap: 17 },
  // Visitors
  { name: 'John Smith', handicap: 15, type: 'visitor' },
  { name: 'Dave Thompson', handicap: 20, type: 'visitor' },
  { name: 'Mike Wilson', handicap: 12, type: 'visitor' },
];

// Course data for all season events
const COURSE_DATA: Record<string, { holes: Array<{ hole: number; par: number; si: number; yardage: number }> }> = {
  'Donabate Golf Club': {
    holes: [
      { hole: 1, par: 4, si: 7, yardage: 387 }, { hole: 2, par: 4, si: 13, yardage: 342 },
      { hole: 3, par: 3, si: 15, yardage: 168 }, { hole: 4, par: 5, si: 3, yardage: 512 },
      { hole: 5, par: 4, si: 1, yardage: 421 }, { hole: 6, par: 4, si: 11, yardage: 365 },
      { hole: 7, par: 3, si: 17, yardage: 155 }, { hole: 8, par: 4, si: 5, yardage: 398 },
      { hole: 9, par: 5, si: 9, yardage: 498 }, { hole: 10, par: 4, si: 8, yardage: 378 },
      { hole: 11, par: 3, si: 16, yardage: 162 }, { hole: 12, par: 4, si: 4, yardage: 408 },
      { hole: 13, par: 3, si: 18, yardage: 148 }, { hole: 14, par: 5, si: 2, yardage: 527 },
      { hole: 15, par: 4, si: 10, yardage: 372 }, { hole: 16, par: 3, si: 14, yardage: 175 },
      { hole: 17, par: 4, si: 6, yardage: 402 }, { hole: 18, par: 4, si: 12, yardage: 358 },
    ],
  },
  'Portmarnock Links': {
    holes: [
      { hole: 1, par: 4, si: 5, yardage: 410 }, { hole: 2, par: 5, si: 11, yardage: 508 },
      { hole: 3, par: 3, si: 17, yardage: 158 }, { hole: 4, par: 4, si: 1, yardage: 445 },
      { hole: 5, par: 4, si: 9, yardage: 385 }, { hole: 6, par: 3, si: 15, yardage: 172 },
      { hole: 7, par: 5, si: 7, yardage: 525 }, { hole: 8, par: 4, si: 3, yardage: 430 },
      { hole: 9, par: 4, si: 13, yardage: 368 }, { hole: 10, par: 4, si: 6, yardage: 402 },
      { hole: 11, par: 3, si: 16, yardage: 165 }, { hole: 12, par: 4, si: 2, yardage: 438 },
      { hole: 13, par: 5, si: 10, yardage: 515 }, { hole: 14, par: 4, si: 8, yardage: 390 },
      { hole: 15, par: 3, si: 18, yardage: 145 }, { hole: 16, par: 4, si: 4, yardage: 425 },
      { hole: 17, par: 4, si: 12, yardage: 375 }, { hole: 18, par: 4, si: 14, yardage: 355 },
    ],
  },
  // Adding more courses for brevity - you can extend this as needed
  'Lahinch Golf Club': {
    holes: [
      { hole: 1, par: 4, si: 11, yardage: 382 }, { hole: 2, par: 5, si: 5, yardage: 530 },
      { hole: 3, par: 3, si: 15, yardage: 152 }, { hole: 4, par: 5, si: 1, yardage: 555 },
      { hole: 5, par: 3, si: 13, yardage: 154 }, { hole: 6, par: 4, si: 3, yardage: 425 },
      { hole: 7, par: 4, si: 9, yardage: 395 }, { hole: 8, par: 4, si: 7, yardage: 405 },
      { hole: 9, par: 4, si: 17, yardage: 340 }, { hole: 10, par: 4, si: 6, yardage: 415 },
      { hole: 11, par: 4, si: 12, yardage: 378 }, { hole: 12, par: 3, si: 18, yardage: 138 },
      { hole: 13, par: 5, si: 2, yardage: 548 }, { hole: 14, par: 4, si: 10, yardage: 382 },
      { hole: 15, par: 4, si: 4, yardage: 432 }, { hole: 16, par: 3, si: 16, yardage: 168 },
      { hole: 17, par: 4, si: 8, yardage: 410 }, { hole: 18, par: 4, si: 14, yardage: 360 },
    ],
  },
};

// Season events schedule
const SEASON_EVENTS = [
  { num: 1, date: '2026-03-24', name: 'Spring Classic', course: 'Donabate Golf Club', location: 'Donabate, Co. Dublin', format: 'Stableford', fee: 60, status: 'finalised', firstTee: '09:30' },
  { num: 2, date: '2026-04-12', name: "Captain's Prize", course: 'Portmarnock Links', location: 'Portmarnock, Co. Dublin', format: 'Strokeplay', fee: 75, status: 'upcoming', firstTee: '09:00' },
  { num: 3, date: '2026-05-03', name: 'Away Day', course: 'Lahinch Golf Club', location: 'Lahinch, Co. Clare', format: 'Stableford', fee: 120, status: 'upcoming', firstTee: '10:00' },
];

const PRIZE_CONFIG = {
  prizes: [
    { type: 'overall', position: 1, label: '1st Overall', value: 50 },
    { type: 'overall', position: 2, label: '2nd Overall', value: 30 },
    { type: 'overall', position: 3, label: '3rd Overall', value: 20 },
    { type: 'division_a', position: 1, label: 'Division A Winner (0-14 hcp)', value: 0 },
    { type: 'division_b', position: 1, label: 'Division B Winner (15-28 hcp)', value: 0 },
    { type: 'best_visitor', position: 1, label: 'Best Visitor', value: 0 },
    { type: 'ntp', hole: 7, label: 'Nearest the Pin - Hole 7', value: 0 },
    { type: 'ntp', hole: 13, label: 'Nearest the Pin - Hole 13', value: 0 },
    { type: 'longest_drive', hole: 4, label: 'Longest Drive - Hole 4', value: 0 },
  ],
};

// F1 Points system
const F1_POINTS = [25, 18, 15, 12, 10, 8, 6, 4, 2, 1];

function generateScore(handicap: number, holes: Array<{ hole: number; par: number; si: number; yardage: number }>): { grossScores: number[]; points: number[] } {
  const grossScores: number[] = [];
  const points: number[] = [];

  for (const hole of holes) {
    const rand = Math.random();
    let deviation: number;

    if (handicap <= 10) {
      if (rand < 0.12) deviation = -1;
      else if (rand < 0.5) deviation = 0;
      else if (rand < 0.8) deviation = 1;
      else deviation = 2;
    } else if (handicap <= 18) {
      if (rand < 0.06) deviation = -1;
      else if (rand < 0.35) deviation = 0;
      else if (rand < 0.7) deviation = 1;
      else if (rand < 0.9) deviation = 2;
      else deviation = 3;
    } else {
      if (rand < 0.03) deviation = -1;
      else if (rand < 0.25) deviation = 0;
      else if (rand < 0.55) deviation = 1;
      else if (rand < 0.8) deviation = 2;
      else deviation = 3;
    }

    const gross = hole.par + deviation;
    const stablefordPts = calculateStablefordPoints(gross, hole.par, hole.si, handicap);
    grossScores.push(gross);
    points.push(stablefordPts);
  }

  return { grossScores, points };
}

export async function seedDatabase() {
  const client = getDb();

  try {
    // Check if already seeded (schema exists and has data)
    const existing = await client.execute('SELECT COUNT(*) as count FROM societies');
    const count = Number(existing.rows[0]?.count) || 0;
    if (count > 0) return; // Already seeded, skip
  } catch {
    // Table doesn't exist yet, need to initialize
  }

  console.log('Initializing database schema...');
  await initializeDb();

  console.log('Seeding database with sample data...');

  // Prepare all data in arrays for batch operations
  const statements = [];

  // Society
  statements.push({
    sql: 'INSERT INTO societies (id, name, logo) VALUES (?, ?, ?)',
    args: [SOCIETY_ID, 'Aer Lingus Golf Society', '⛳']
  });

  // Society Settings
  const settings = [
    ['admin_pin', '2026'],
    ['society_name', 'Aer Lingus Golf Society'],
    ['default_format', 'Stableford'],
    ['default_fee', '60'],
    ['captain', 'Séamus O\'Brien'],
    ['secretary', 'Pádraig Murphy'],
    ['treasurer', 'Ciarán Kelly'],
    // Handicap deductions for prize winners
    ['deduction_1st', '3'],
    ['deduction_2nd', '2'],
    ['deduction_3rd', '2'],
    ['deduction_front9', '1'],
    ['deduction_back9', '1'],
  ];
  for (const [key, value] of settings) {
    statements.push({
      sql: 'INSERT OR REPLACE INTO society_settings (key, value) VALUES (?, ?)',
      args: [key, value]
    });
  }

  // Members
  const memberIds: string[] = [];
  const usedTokens = new Set<string>();
  const usedPins = new Set<string>();

  function generateMemberPin(): string {
    let pin: string;
    do {
      pin = String(1000 + Math.floor(Math.random() * 9000)); // 1000-9999
    } while (usedPins.has(pin));
    usedPins.add(pin);
    return pin;
  }

  for (const m of MEMBERS) {
    const id = uuidv4();
    memberIds.push(id);
    const token = generateAccessToken(m.name, usedTokens);
    const pin = generateMemberPin();
    statements.push({
      sql: 'INSERT INTO members (id, society_id, name, handicap, email, phone, member_type, access_token, member_pin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      args: [id, SOCIETY_ID, m.name, m.handicap, `${m.name.toLowerCase().replace(/[^a-z]/g, '.')}@email.com`, '', m.type || 'member', token, pin]
    });
  }

  // Season
  const bonusConfig = JSON.stringify({
    ntp: 1,  // 1 bonus point for NTP win
    ld: 1,   // 1 bonus point for LD win
  });
  statements.push({
    sql: 'INSERT INTO seasons (id, society_id, name, year, start_date, end_date, points_system, best_of_x, total_events, bonus_config, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    args: [SEASON_ID, SOCIETY_ID, '2026 Season', 2026, '2026-03-01', '2026-10-31', 'f1', 8, 12, bonusConfig, 'active']
  });

  // Create all season events with course holes
  const eventIds: string[] = [];
  for (const evt of SEASON_EVENTS) {
    const eventId = evt.num === 1 ? EVENT_ID : `evt_${evt.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${evt.num}`;
    eventIds.push(eventId);
    statements.push({
      sql: 'INSERT INTO events (id, society_id, name, course_name, date, format, entry_fee, first_tee, status, prize_config, season_id, event_number, location, notes, results_published) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      args: [eventId, SOCIETY_ID, evt.name, evt.course, evt.date, evt.format, evt.fee, evt.firstTee, evt.status, JSON.stringify(PRIZE_CONFIG), SEASON_ID, evt.num, evt.location, null, evt.status === 'finalised' ? 1 : 0]
    });

    // Insert course holes for each event
    const courseData = COURSE_DATA[evt.course];
    if (courseData) {
      for (const h of courseData.holes) {
        statements.push({
          sql: 'INSERT INTO course_holes (id, event_id, hole_number, par, stroke_index, yardage) VALUES (?, ?, ?, ?, ?, ?)',
          args: [uuidv4(), eventId, h.hole, h.par, h.si, h.yardage]
        });
      }
    }
  }

  // RSVPs for Spring Classic (first event)
  const regularMembers = memberIds.slice(0, 40);
  const visitorMembers = memberIds.slice(40);

  for (let i = 0; i < regularMembers.length; i++) {
    let status: string;
    if (i < 32) status = 'confirmed';
    else if (i < 36) status = 'maybe';
    else if (i < 38) status = 'declined';
    else continue;
    statements.push({
      sql: 'INSERT OR REPLACE INTO rsvps (id, event_id, member_id, status) VALUES (?, ?, ?, ?)',
      args: [uuidv4(), EVENT_ID, regularMembers[i], status]
    });
  }

  for (const vid of visitorMembers) {
    statements.push({
      sql: 'INSERT OR REPLACE INTO rsvps (id, event_id, member_id, status) VALUES (?, ?, ?, ?)',
      args: [uuidv4(), EVENT_ID, vid, 'confirmed']
    });
  }

  // Generate scores and results for Spring Classic
  const allConfirmed = [...regularMembers.slice(0, 32), ...visitorMembers];
  const donabateHoles = COURSE_DATA['Donabate Golf Club'].holes;

  interface PlayerScore {
    memberId: string;
    memberIdx: number;
    handicap: number;
    grossScores: number[];
    points: number[];
    totalGross: number;
    totalPoints: number;
    scorecardId: string;
  }
  const playerScores: PlayerScore[] = [];

  for (let i = 0; i < allConfirmed.length; i++) {
    const memberId = allConfirmed[i];
    const memberIdx = memberIds.indexOf(memberId);
    const handicap = MEMBERS[memberIdx].handicap;
    const scorecardId = uuidv4();

    const { grossScores, points } = generateScore(handicap, donabateHoles);

    // Ensure reasonable totals
    const adjustedPoints = [...points];
    let totalPts = adjustedPoints.reduce((a, b) => a + b, 0);

    // Clamp to realistic range 28-42
    if (totalPts > 42) {
      for (let h = 0; h < 18 && totalPts > 42; h++) {
        if (adjustedPoints[h] > 2) { adjustedPoints[h]--; totalPts--; }
      }
    } else if (totalPts < 28) {
      for (let h = 0; h < 18 && totalPts < 28; h++) {
        if (adjustedPoints[h] < 2) { adjustedPoints[h]++; totalPts++; }
      }
    }

    const adjustedGross = grossScores.map((g, idx) => {
      const diff = points[idx] - adjustedPoints[idx];
      return g + diff;
    });

    const totalGross = adjustedGross.reduce((a, b) => a + b, 0);
    const totalPoints = adjustedPoints.reduce((a, b) => a + b, 0);

    playerScores.push({
      memberId, memberIdx, handicap,
      grossScores: adjustedGross, points: adjustedPoints,
      totalGross, totalPoints, scorecardId,
    });
  }

  // Sort by total points descending
  playerScores.sort((a, b) => b.totalPoints - a.totalPoints || a.totalGross - b.totalGross);

  // Insert scorecards and hole scores
  for (const ps of playerScores) {
    statements.push({
      sql: 'INSERT INTO scorecards (id, event_id, member_id, status, total_gross, total_points, submitted_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      args: [ps.scorecardId, EVENT_ID, ps.memberId, 'submitted', ps.totalGross, ps.totalPoints, '2026-03-24T16:00:00']
    });
    
    for (let h = 0; h < 18; h++) {
      statements.push({
        sql: 'INSERT INTO hole_scores (id, scorecard_id, hole_number, gross_score, stableford_points) VALUES (?, ?, ?, ?, ?)',
        args: [uuidv4(), ps.scorecardId, h + 1, ps.grossScores[h], ps.points[h]]
      });
    }
  }

  // Add some basic activities
  statements.push({
    sql: 'INSERT INTO activity_log (id, event_id, member_id, action, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    args: [uuidv4(), EVENT_ID, null, 'event_created', 'Spring Classic event created', '2026-03-01T10:00:00']
  });

  statements.push({
    sql: 'INSERT INTO activity_log (id, event_id, member_id, action, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    args: [uuidv4(), EVENT_ID, null, 'event_finalised', 'Spring Classic results finalised', '2026-03-24T17:00:00']
  });

  // Execute all statements in batches
  const batchSize = 100;
  for (let i = 0; i < statements.length; i += batchSize) {
    const batch = statements.slice(i, i + batchSize);
    await client.batch(batch);
  }

  console.log('Database seeded successfully!');
}

if (require.main === module) {
  seedDatabase().catch(console.error);
}