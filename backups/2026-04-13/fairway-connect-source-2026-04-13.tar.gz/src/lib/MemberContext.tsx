'use client';

import { createContext, useContext, useEffect, useState, useCallback } from 'react';

interface MemberIdentity {
  id: string;
  name: string;
  handicap: number;
}

interface MemberContextType {
  member: MemberIdentity | null;
  isIdentified: boolean;
  setMember: (m: MemberIdentity) => void;
  clearMember: () => void;
}

const MemberContext = createContext<MemberContextType>({
  member: null,
  isIdentified: false,
  setMember: () => {},
  clearMember: () => {},
});

export function MemberProvider({ children }: { children: React.ReactNode }) {
  const [member, setMemberState] = useState<MemberIdentity | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Load from localStorage on mount
    const id = localStorage.getItem('fc_member_id');
    const name = localStorage.getItem('fc_member_name');
    const handicap = localStorage.getItem('fc_member_handicap');
    if (id && name) {
      setMemberState({ id, name, handicap: Number(handicap) || 0 });
    }
    setLoaded(true);
  }, []);

  const setMember = useCallback((m: MemberIdentity) => {
    localStorage.setItem('fc_member_id', m.id);
    localStorage.setItem('fc_member_name', m.name);
    localStorage.setItem('fc_member_handicap', String(m.handicap));
    setMemberState(m);
  }, []);

  const clearMember = useCallback(() => {
    localStorage.removeItem('fc_member_id');
    localStorage.removeItem('fc_member_name');
    localStorage.removeItem('fc_member_handicap');
    setMemberState(null);
  }, []);

  if (!loaded) return null;

  return (
    <MemberContext.Provider value={{ member, isIdentified: !!member, setMember, clearMember }}>
      {children}
    </MemberContext.Provider>
  );
}

export function useMember() {
  return useContext(MemberContext);
}
