import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { seedDatabase } from '@/lib/seed';

export const dynamic = 'force-dynamic';

export async function GET() {
  await seedDatabase();
  const db = getDb();

  // Get the most recent finalised event
  const eventResult = await db.execute("SELECT id FROM events WHERE status = 'finalised' ORDER BY date DESC LIMIT 1");
  const eventId = (eventResult.rows[0] as unknown as {id:string} | undefined)?.id;
  if (!eventId) return NextResponse.json({ results: [], event: null, finalised: false });

  const eventDetailResult = await db.execute({ sql: 'SELECT * FROM events WHERE id = ?', args: [eventId] });
  const event = eventDetailResult.rows[0] as unknown as {status:string} & Record<string,unknown>;

  const resultsResult = await db.execute({
    sql: `
      SELECT pa.*, m.name as member_name, m.handicap
      FROM prize_allocations pa
      JOIN members m ON m.id = pa.member_id
      WHERE pa.event_id = ?
      ORDER BY 
        CASE pa.prize_type 
          WHEN 'overall' THEN 1 WHEN 'class_1' THEN 1 WHEN 'class_2' THEN 1
          WHEN 'front_9' THEN 2 WHEN 'class_1_front_9' THEN 2 WHEN 'class_2_front_9' THEN 2
          WHEN 'back_9' THEN 3 WHEN 'class_1_back_9' THEN 3 WHEN 'class_2_back_9' THEN 3
          WHEN 'ntp' THEN 4 
          WHEN 'longest_drive' THEN 5
          WHEN 'twos' THEN 6
          WHEN 'division_a' THEN 7 WHEN 'division_b' THEN 7
          WHEN 'best_visitor' THEN 8
          ELSE 9
        END,
        pa.position
    `,
    args: [eventId]
  });
  const results = resultsResult.rows;

  // Also get side comps
  const sideCompsResult = await db.execute({
    sql: `SELECT sc.*, m.name as member_name FROM side_comps sc LEFT JOIN members m ON m.id = sc.member_id WHERE sc.event_id = ? ORDER BY sc.type, sc.hole_number`,
    args: [eventId]
  });

  return NextResponse.json({
    results,
    sideComps: sideCompsResult.rows,
    event,
    finalised: event.status === 'finalised',
  });
}
